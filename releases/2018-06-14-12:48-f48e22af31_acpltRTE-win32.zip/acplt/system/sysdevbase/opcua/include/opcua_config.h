
#ifndef OV_COMPILE_LIBRARY_opcua
#define OV_COMPILE_LIBRARY_opcua
#endif


#include "opcua.h"

#define KSOPC_IDENTIFIER		"OPC_UA-BINARY"



