
union varunion
{
	OV_BYTE 		val_byte;
	OV_BOOL 		val_bool;
	OV_INT			val_int;		
	OV_UINT			val_uint;		
	OV_SINGLE		val_single;		
	OV_DOUBLE		val_double;		
	OV_STRING		val_string;		
	OV_TIME			val_time;		
	OV_TIME_SPAN	val_time_span;	
};