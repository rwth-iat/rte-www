/* Returns a url-decoded version of str Public Domain code from http://www.geekhideout.com/urlcode.shtml*/
/* IMPORTANT: be sure to ov_memstack_lock/unlock() arround */
OV_STRING url_decode(OV_STRING str);
