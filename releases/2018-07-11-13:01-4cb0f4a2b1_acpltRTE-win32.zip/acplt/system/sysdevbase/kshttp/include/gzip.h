OV_RESULT gzip(OV_BYTE* inputdata, OV_INT inputlength, OV_BYTE** outputdata, OV_INT* outputlength);
